export class Translator {
  text: string = '';
  translated: string = '';
  translation: string = '';
}


