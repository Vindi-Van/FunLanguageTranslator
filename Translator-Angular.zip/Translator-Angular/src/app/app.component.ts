import { Component } from '@angular/core';
import { Translator } from './model/translator';
import { ApiService } from './service/api.service';
import { MatSnackBar, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Translator';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  content = new Translator();
  languages: string[] = ['pirate', 'yoda', 'valspeak', 'minion'];

  constructor(
    private apiService: ApiService,
    private snackBar: MatSnackBar
) { }

  ngOnInit() {
    this.content.translation = this.languages[0];
  }

  translate(){
    this.apiService.getTranslation(this.content).subscribe( data => {
      this.content.translated = data.contents.translated;
    }, err => {
      this.snackBar.open(err.error.error.message, 'cancel',{
        verticalPosition: this.verticalPosition,
      });
    });
  }
}
