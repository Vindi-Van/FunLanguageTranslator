import { Injectable } from '@angular/core';
import { HttpClient, HttpParams  } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Translator } from '../model/translator';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiRoot = environment.translateEndpoint;

  constructor(private http: HttpClient) { }

  getTranslation(body: Translator): Observable<any> {
    let endPoint = `${this.apiRoot}${body.translation}.json`;
    return this.http.get<any>(endPoint, {
      params: {
        text: body.text
      }
    });
  }
}
